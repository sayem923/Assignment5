// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';

class GridViewPage extends StatelessWidget {
  final items = List<String>.generate(12, (i) => "Box ${i + 1}");

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("GridView")),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3),
        itemCount: items.length,
        itemBuilder: (context, index) => Card(
          margin: EdgeInsets.all(8),
          color: Colors.blueAccent,
          child: Center(child: Text(items[index], style: TextStyle(color: Colors.white))),
        ),
      ),
    );
  }
}
