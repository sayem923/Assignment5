// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:flutter_project/GridViewPage.dart';
import 'package:flutter_project/RegisterPage.dart';
// ignore: unused_import
import 'login_page.dart';
// ignore: unused_import
import 'grid_view_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Assignment 5',
      home: HomePage(),
      routes: {
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/gridview': (context) => GridViewPage(),
      },
    );
  }
}

class ListViewPage {
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Main Page")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/login'), child: Text("Login")),
            ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/register'), child: Text("Register")),
            ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/listview'), child: Text("ListView")),
            ElevatedButton(onPressed: () => Navigator.pushNamed(context, '/gridview'), child: Text("GridView")),
          ],
        ),
      ),
    );
  }
}
